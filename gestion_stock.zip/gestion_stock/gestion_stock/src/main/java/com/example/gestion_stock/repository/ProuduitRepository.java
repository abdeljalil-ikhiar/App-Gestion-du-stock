package com.example.gestion_stock.repository;

import com.example.gestion_stock.entities.Prouduit;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProuduitRepository extends JpaRepository<Prouduit,Integer> {
    @Query("SELECT p.Reference AS Reference, " +
            "p.Designation AS Designation, " +
            "COALESCE(SUM(inv.QuantiteInventaire), 0) AS SommeQuantiteInventaire, " +
            "COALESCE(SUM(srt.QuantiteSortie), 0) AS SommeQuantiteSortie, " +
            "COALESCE(SUM(ent.QuantiteEntrer), 0) AS SommeQuantiteEntrer, " +
            "COALESCE(SUM(ent.QuantiteEntrer), 0) - COALESCE(SUM(srt.QuantiteSortie), 0) + COALESCE(SUM(inv.QuantiteInventaire), 0) AS StockFinal " +
            "FROM Prouduit p " +
            "LEFT JOIN p.inventaires inv " +
            "LEFT JOIN p.sorties srt " +
            "LEFT JOIN p.entrers ent " +
            "GROUP BY p.Reference, p.Designation")
    List<Object[]> getStockFinal();

}
