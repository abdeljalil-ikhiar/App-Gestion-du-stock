package com.example.gestion_stock.Service;
import com.example.gestion_stock.entities.Entrer;
import com.example.gestion_stock.entities.Prouduit;
import com.example.gestion_stock.repository.EntrerRepository;
import com.example.gestion_stock.repository.ProuduitRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class EntrerService implements EntrerManager{
    @Autowired
    private EntrerRepository entrerRepository;
    @Autowired
    private ProuduitRepository prouduitRepository;
    @Override
    public Entrer addEntrer(Entrer entrer) {
        return entrerRepository.save(entrer);
    }

    @Override
    public Entrer updateEntrer(Entrer entrer) {
        Integer id = entrer.getEntrerID(); // Supposons que votre ID soit stocké dans un champ nommé "EntrerID"
        Optional<Entrer> existingEntrerOptional = entrerRepository.findById(id);

        if (existingEntrerOptional.isPresent()) {
            // L'entrée existe, mettez à jour ses détails
            Entrer existingEntrer = existingEntrerOptional.get();
            existingEntrer.setProuduit(entrer.getProuduit());
            existingEntrer.setQuantiteEntrer(entrer.getQuantiteEntrer());
            existingEntrer.setDateEntrer(entrer.getDateEntrer()); // Ajoutez cette ligne si vous souhaitez mettre à jour la date d'entrée

            // Enregistrer et retourner l'entrée mise à jour
            return entrerRepository.save(existingEntrer);
        } else {
            // L'entrée n'existe pas dans la base de données
            throw new RuntimeException("Entrer avec l'ID " + id + " non trouvé");
        }
    }

    @Override
    public boolean deleteEntrer(Integer id) {
        if (entrerRepository.existsById(id)) {
            entrerRepository.deleteById(id);
            return true;
        }
        return false;    }

    @Override
    public List<Entrer> getAllEntrer() {
       return entrerRepository.findAll();
    }

    @Override
    public List<Prouduit> getAllProduits() {
        // Implémentez la logique pour récupérer tous les produits depuis votre repository ProuduitRepository
        return prouduitRepository.findAll();
    }
}
