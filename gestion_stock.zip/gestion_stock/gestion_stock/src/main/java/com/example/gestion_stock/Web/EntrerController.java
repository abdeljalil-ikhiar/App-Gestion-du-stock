package com.example.gestion_stock.Web;
import com.example.gestion_stock.Service.EntrerService;
import com.example.gestion_stock.Service.ProuduitService;
import com.example.gestion_stock.entities.Entrer;
import com.example.gestion_stock.entities.Prouduit;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
@AllArgsConstructor
public class EntrerController {

    @Autowired
    private EntrerService entrerService;

    @Autowired
    private ProuduitService produitService;

    @GetMapping("/entrees")
    public String listEntrees(Model model) {
        List<Entrer> entrees = entrerService.getAllEntrer();
        model.addAttribute("entrees", entrees);
        return "entrees";
    }

    @ModelAttribute("produits")
    public List<Prouduit> produits() {
        return entrerService.getAllProduits();
    }

    @PostMapping("/addEntree")
    public String addEntree(@ModelAttribute Entrer entree, RedirectAttributes redirectAttributes) {
        Prouduit produit = produitService.getProuduitById(entree.getProuduitId());
        if (produit == null) {
            redirectAttributes.addFlashAttribute("error", "Produit non trouvé.");
            return "redirect:/entrees";
        }
        entree.setProuduit(produit);
        entrerService.addEntrer(entree);
        return "redirect:/entrees";
    }

    @PostMapping("/updateEntree")
    public String updateEntree(@ModelAttribute Entrer entree, RedirectAttributes redirectAttributes) {
        if (entree.getProuduitId() == null) {
            redirectAttributes.addFlashAttribute("error", "L'ID du produit ne peut pas être null.");
            return "redirect:/entrees";
        }
        Prouduit produit = produitService.getProuduitById(entree.getProuduitId());
        if (produit == null) {
            redirectAttributes.addFlashAttribute("error", "Produit non trouvé.");
            return "redirect:/entrees";
        }
        entree.setProuduit(produit);
        entrerService.updateEntrer(entree);
        return "redirect:/entrees";
    }

    @PostMapping("/deleteEntree/{id}")
    public String deleteEntree(@PathVariable("id") Integer id) {
        entrerService.deleteEntrer(id);
        return "redirect:/entrees";
    }
}
