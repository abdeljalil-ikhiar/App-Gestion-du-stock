package com.example.gestion_stock.Service;

import com.example.gestion_stock.entities.Prouduit;
import com.example.gestion_stock.entities.Sorties;
import com.example.gestion_stock.repository.ProuduitRepository;
import com.example.gestion_stock.repository.SortiesRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class SortiesService implements SortieManager{
    @Autowired
    private SortiesRepository sortiesRepository;
    @Autowired
    private ProuduitRepository prouduitRepository;
    @Override
    public Sorties addSorties(Sorties sorties) {
        return sortiesRepository.save(sorties);
    }

    @Override
    public Sorties updateSorties(Sorties sorties) {
        Integer id = sorties.getSortieID(); // Supposons que votre ID soit stocké dans un champ nommé "EntrerID"
        Optional<Sorties> existingSortieOptional = sortiesRepository.findById(id);

        if (existingSortieOptional.isPresent()) {
            // L'entrée existe, mettez à jour ses détails
            Sorties existingSortie = existingSortieOptional.get();
            existingSortie.setProuduit(sorties.getProuduit());
            existingSortie.setQuantiteSortie(sorties.getQuantiteSortie());
            existingSortie.setDateSortie(sorties.getDateSortie()); // Ajoutez cette ligne si vous souhaitez mettre à jour la date d'entrée

            // Enregistrer et retourner l'entrée mise à jour
            return sortiesRepository.save(existingSortie);
        } else {
            // L'entrée n'existe pas dans la base de données
            throw new RuntimeException("Sortie avec l'ID " + id + " non trouvé");
        }
    }

    @Override
    public boolean deleteSorties(Integer id) {
        if (sortiesRepository.existsById(id)) {
            sortiesRepository.deleteById(id);
            return true;
        }
        return false;
    }

    @Override
    public List<Sorties> getAllSorties() {
        return sortiesRepository.findAll();
    }

    @Override
    public List<Prouduit> getAllProduits() {
        // Implémentez la logique pour récupérer tous les produits depuis votre repository ProuduitRepository
        return prouduitRepository.findAll();
    }
}
