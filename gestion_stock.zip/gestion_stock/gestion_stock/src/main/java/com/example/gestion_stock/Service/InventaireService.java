package com.example.gestion_stock.Service;
import com.example.gestion_stock.entities.Inventaire;
import com.example.gestion_stock.entities.Prouduit;
import com.example.gestion_stock.repository.InventaireRepository;
import com.example.gestion_stock.repository.ProuduitRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class InventaireService implements InventaireManager{
    @Autowired
    private InventaireRepository inventaireRepository;
    @Autowired
    private ProuduitRepository prouduitRepository;
    @Override
    public Inventaire addInventaire(Inventaire inventaire) {
        return inventaireRepository.save(inventaire);
    }

    @Override
    public Inventaire updateInventaire(Inventaire inventaire) {
        Integer id = inventaire.getInventaireID(); // Supposons que votre ID soit stocké dans un champ nommé "EntrerID"
        Optional<Inventaire> existingInventaireOptional = inventaireRepository.findById(id);

        if (existingInventaireOptional.isPresent()) {
            // L'entrée existe, mettez à jour ses détails
            Inventaire existingInventaire = existingInventaireOptional.get();
            existingInventaire.setProuduit(inventaire.getProuduit());
            existingInventaire.setQuantiteInventaire(inventaire.getQuantiteInventaire());
            existingInventaire.setDateInventaire(inventaire.getDateInventaire()); // Ajoutez cette ligne si vous souhaitez mettre à jour la date d'entrée

            // Enregistrer et retourner l'entrée mise à jour
            return inventaireRepository.save(existingInventaire);
        } else {
            // L'entrée n'existe pas dans la base de données
            throw new RuntimeException("Inventaire avec l'ID " + id + " non trouvé");
        }
    }

    @Override
    public boolean deleteInventaire(Integer id) {
        if (inventaireRepository.existsById(id)) {
            inventaireRepository.deleteById(id);
            return true;
        }
        return false;
    }

    @Override
    public List<Inventaire> getAllInventaire() {
        return inventaireRepository.findAll();
    }

    @Override
    public Inventaire getInventaireById(Integer id) {
        Optional<Inventaire> inventaireOptional = inventaireRepository.findById(id);
        return inventaireOptional.orElse(null);
    }

    @Override
    public List<Prouduit> getAllProduits() {
        // Implémentez la logique pour récupérer tous les produits depuis votre repository ProuduitRepository
        return prouduitRepository.findAll();
    }

}


