package com.example.gestion_stock.entities;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "Sortie")
@Data
public class Sorties {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer SortieID;
    @ManyToOne
    @JoinColumn(name = "Prouduit_id")
    private Prouduit prouduit;
    private double QuantiteSortie;
    @DateTimeFormat(iso= DateTimeFormat.ISO.DATE)
    private Date DateSortie;
    @Transient
    private Integer prouduitId;

}
