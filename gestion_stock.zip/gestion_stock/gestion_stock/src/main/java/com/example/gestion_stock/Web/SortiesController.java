package com.example.gestion_stock.Web;
import com.example.gestion_stock.Service.ProuduitService;
import com.example.gestion_stock.Service.SortiesService;
import com.example.gestion_stock.entities.Prouduit;
import com.example.gestion_stock.entities.Sorties;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
@AllArgsConstructor
public class SortiesController {

    @Autowired
    private SortiesService sortiesService;

    @Autowired
    private ProuduitService produitService;

    @GetMapping("/sorties")
    public String listSorties(Model model) {
        List<Sorties> sorties = sortiesService.getAllSorties();
        model.addAttribute("sorties", sorties);
        return "sorties";
    }

    @ModelAttribute("produits")
    public List<Prouduit> produits() {
        return produitService.getAllProuduit();
    }

    @PostMapping("/addSortie")
    public String addSortie(@ModelAttribute Sorties sortie, RedirectAttributes redirectAttributes) {
        Prouduit produit = produitService.getProuduitById(sortie.getProuduitId());
        if (produit == null) {
            redirectAttributes.addFlashAttribute("error", "Produit non trouvé.");
            return "redirect:/sorties";
        }
        sortie.setProuduit(produit);
        sortiesService.addSorties(sortie);
        return "redirect:/sorties";
    }

    @PostMapping("/updateSortie")
    public String updateSortie(@ModelAttribute Sorties sortie, RedirectAttributes redirectAttributes) {
        if (sortie.getProuduitId() == null) {
            redirectAttributes.addFlashAttribute("error", "L'ID du produit ne peut pas être null.");
            return "redirect:/sorties";
        }
        Prouduit produit = produitService.getProuduitById(sortie.getProuduitId());
        if (produit == null) {
            redirectAttributes.addFlashAttribute("error", "Produit non trouvé.");
            return "redirect:/sorties";
        }
        sortie.setProuduit(produit);
        sortiesService.updateSorties(sortie);
        return "redirect:/sorties";
    }

    @PostMapping("/deleteSortie/{id}")
    public String deleteSortie(@PathVariable("id") Integer id) {
        sortiesService.deleteSorties(id);
        return "redirect:/sorties";
    }
}
