package com.example.gestion_stock.repository;

import com.example.gestion_stock.entities.Inventaire;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface InventaireRepository extends JpaRepository<Inventaire,Integer> {
}
