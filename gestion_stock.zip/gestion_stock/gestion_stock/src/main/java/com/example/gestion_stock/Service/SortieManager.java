package com.example.gestion_stock.Service;

import com.example.gestion_stock.entities.Prouduit;
import com.example.gestion_stock.entities.Sorties;
import org.springframework.stereotype.Service;

import java.util.List;
public interface SortieManager {
    public Sorties addSorties(Sorties sorties);
    public Sorties updateSorties(Sorties sorties);
    public boolean deleteSorties(Integer id );

    public List<Sorties> getAllSorties();
    List<Prouduit> getAllProduits();
}
