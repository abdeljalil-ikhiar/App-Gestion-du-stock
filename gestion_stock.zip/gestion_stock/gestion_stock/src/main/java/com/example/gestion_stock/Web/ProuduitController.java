package com.example.gestion_stock.Web;
import com.example.gestion_stock.Service.ProuduitService;
import com.example.gestion_stock.entities.Prouduit;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
@Controller
@AllArgsConstructor
public class ProuduitController {
    @Autowired
    private ProuduitService prouduitService;

    @GetMapping(path = "/home")
    public String listProduitsAction(Model model) {
        List<Prouduit> products = prouduitService.getAllProuduit();
        model.addAttribute("listProduitsmodel", products);
        model.addAttribute("produit", new Prouduit());
        return "home";
    }

    @PostMapping("/addProduit")
    public String addProduit(@ModelAttribute Prouduit produit) {
        prouduitService.addProuduit(produit);
        return "redirect:/home";
    }

    // Endpoint pour la mise à jour d'un produit
    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable("id") Integer id, Model model) {
        Prouduit produit = prouduitService.getProuduitById(id);
        if (produit != null) {
            model.addAttribute("produit", produit);
            return "home"; // Nom de la vue pour le formulaire de mise à jour
        } else {
            return "redirect:/home"; // Redirection si le produit n'est pas trouvé
        }
    }

    // Soumettre le formulaire de mise à jour
    @PostMapping(path = "/update") // Ajouter l'ID dans le chemin d'accès
    public String updateProuduit(@ModelAttribute Prouduit produit) {
        // Vérifier si l'ID est null ou vide
        if (produit.getId() == null) {
            // Gérer le cas où l'ID est manquant ou incorrect
            return "redirect:/home"; // Redirection vers une page d'erreur ou une vue appropriée
        }
        // Convertir l'ID en un entier


        // Votre logique de mise à jour du produit ici...
        // Vérifiez si l'ID fourni correspond à un produit existant
        Prouduit existingProuduit = prouduitService.getProuduitById(produit.getId());
        if (existingProuduit != null) {
            // Mettez à jour les détails du produit avec les nouvelles valeurs
            existingProuduit.setReference(produit.getReference());
            existingProuduit.setDesignation(produit.getDesignation());
            // Effectuez la mise à jour dans le service
            prouduitService.updateProuduit(existingProuduit);
            // Redirigez vers une page de confirmation ou une autre vue appropriée
            return "redirect:/home"; // Redirection vers une page d'affichage du produit mis à jour
        } else {
            // Si aucun produit correspondant n'est trouvé, renvoyez une erreur ou redirigez vers une page d'erreur
            return "redirect:/home"; // Redirection vers une page d'erreur générique
        }
    }

    @PostMapping("/deleteProduit/{id}")
    public String deleteProduit(@PathVariable("id") Integer id) {
        prouduitService.deleteProuduit(id);
        return "redirect:/home";
    }

    @GetMapping(path = "/stock-final")
    public String getStockFinal(Model model) {
        List<Object[]> stockFinal = prouduitService.getStockFinal();
        List<Map<String, Object>> stockFinalList = stockFinal.stream().map(row -> {
            Map<String, Object> result = new HashMap<>();
            result.put("Reference", row[0]);
            result.put("Designation", row[1]);
            result.put("SommeQuantiteInventaire", row[2]);
            result.put("SommeQuantiteSortie", row[3]);
            result.put("SommeQuantiteEntrer", row[4]);
            result.put("StockFinal", row[5]);
            return result;
        }).toList();
        model.addAttribute("stockFinalList", stockFinalList);
        return "stockFinal"; // Nom de la vue pour afficher le stock final
    }


}