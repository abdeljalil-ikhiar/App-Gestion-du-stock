package com.example.gestion_stock.Web;
import com.example.gestion_stock.Service.InventaireService;
import com.example.gestion_stock.Service.ProuduitService;
import com.example.gestion_stock.entities.Inventaire;
import com.example.gestion_stock.entities.Prouduit;
import com.example.gestion_stock.repository.ProuduitRepository;
import lombok.AllArgsConstructor;
import org.apache.logging.log4j.message.Message;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
@AllArgsConstructor
public class InventaireController {

    @Autowired
    private InventaireService inventaireService;
    @Autowired
   private ProuduitService prouduitService;



    @GetMapping("/inventaires")
    public String listInventaires(Model model) {
        List<Inventaire> inventaires = inventaireService.getAllInventaire();
        model.addAttribute("inventaires", inventaires);
        return "inventaires";
    }

    @ModelAttribute("produits")
    public List<Prouduit> prouduits() {
        return inventaireService.getAllProduits();
    }
    @PostMapping("/addInventaire")
    public String addInventaire(@ModelAttribute Inventaire inventaires) {
         Prouduit produits =  prouduitService.getProuduitById(inventaires.getProuduitId());
        inventaires.setProuduit(produits);
        inventaireService.addInventaire(inventaires);
        return "redirect:/inventaires";
    }

    @PostMapping("/updateInventaire")
    public String updateInventaire(@ModelAttribute Inventaire inventaires, RedirectAttributes redirectAttributes) {
        if (inventaires.getProuduitId() == null) {
            redirectAttributes.addFlashAttribute("error", "L'ID du produit ne peut pas être null.");
            return "redirect:/inventaires";
        }
        Prouduit prouduit = prouduitService.getProuduitById(inventaires.getProuduitId());
        inventaires.setProuduit(prouduit);
        inventaireService.updateInventaire(inventaires);
        return "redirect:/inventaires";
    }


    @PostMapping("/deleteInventaire/{id}")
    public String deleteInventaire(@PathVariable("id") Integer id) {
        inventaireService.deleteInventaire(id);
        return "redirect:/inventaires";
    }
}
