package com.example.gestion_stock.Service;

import com.example.gestion_stock.entities.Entrer;
import com.example.gestion_stock.entities.Inventaire;
import com.example.gestion_stock.entities.Prouduit;

import java.util.List;

public interface InventaireManager {
    public Inventaire addInventaire(Inventaire inventaire);
    public Inventaire updateInventaire(Inventaire inventaire);
    public boolean deleteInventaire(Integer id );

    public List<Inventaire> getAllInventaire();
    public Inventaire getInventaireById(Integer id);
    List<Prouduit> getAllProduits();
}
