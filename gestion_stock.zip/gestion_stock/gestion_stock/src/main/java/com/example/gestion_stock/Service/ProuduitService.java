package com.example.gestion_stock.Service;

import com.example.gestion_stock.entities.Prouduit;
import com.example.gestion_stock.repository.ProuduitRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
@Service
public class ProuduitService implements ProuduitManager{
    @Autowired
    private ProuduitRepository prouduitRepository;
    @Override
    public Prouduit addProuduit(Prouduit prouduit) {
        return  prouduitRepository.save(prouduit);    }

    @Override
    public Prouduit updateProuduit(Prouduit prouduit) {
        Integer id = prouduit.getId(); // Supposons que votre ID soit stocké dans un champ nommé "EntrerID"
        Optional<Prouduit> existingprouduitOptional = prouduitRepository.findById(id);

        if (existingprouduitOptional.isPresent()) {
            // L'entrée existe, mettez à jour ses détails
            Prouduit existingprouduit = existingprouduitOptional.get();
            existingprouduit.setReference(prouduit.getReference());
            existingprouduit.setDesignation(prouduit.getDesignation());


            // Enregistrer et retourner l'entrée mise à jour
            return prouduitRepository.save(existingprouduit);
        } else {
            // L'entrée n'existe pas dans la base de données
            throw new RuntimeException("Prouduit avec l'ID " + id + " non trouvé");
        }
    }

    @Override
    public boolean deleteProuduit(Integer id) {
        if (prouduitRepository.existsById(id)) {
            prouduitRepository.deleteById(id);
            return true;
        }
        return false;
    }

    @Override
    public List<Prouduit> getAllProuduit() {
        return prouduitRepository.findAll();

    }

    @Override
    public Prouduit getProuduitById(Integer id) {
        Optional<Prouduit> prouduitOptional = prouduitRepository.findById(id);
        return prouduitOptional.orElse(null);
    }

    @Override
    public List<Object[]> getStockFinal() {
        return prouduitRepository.getStockFinal();
    }

}
