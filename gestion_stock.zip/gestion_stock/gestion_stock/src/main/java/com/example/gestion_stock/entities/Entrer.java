package com.example.gestion_stock.entities;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
@Table(name = "Entrer")
public class Entrer {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer EntrerID;
    @ManyToOne
    @JoinColumn(name = "Prouduit_id")
    private Prouduit prouduit;
    private double QuantiteEntrer;
    @DateTimeFormat(iso= DateTimeFormat.ISO.DATE)
    private Date DateEntrer;
    @Transient
    private Integer prouduitId;
}
