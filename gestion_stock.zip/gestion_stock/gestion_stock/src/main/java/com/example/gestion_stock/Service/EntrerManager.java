package com.example.gestion_stock.Service;

import com.example.gestion_stock.entities.Entrer;
import com.example.gestion_stock.entities.Prouduit;

import java.util.List;

public interface EntrerManager {
    public Entrer addEntrer(Entrer entrer);
    public Entrer updateEntrer(Entrer entrer);
    public boolean deleteEntrer(Integer id );

    public List<Entrer> getAllEntrer();
    public List<Prouduit> getAllProduits();

}
