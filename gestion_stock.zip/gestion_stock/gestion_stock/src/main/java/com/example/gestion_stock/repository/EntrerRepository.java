package com.example.gestion_stock.repository;

import com.example.gestion_stock.entities.Entrer;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EntrerRepository extends JpaRepository<Entrer,Integer> {
}
