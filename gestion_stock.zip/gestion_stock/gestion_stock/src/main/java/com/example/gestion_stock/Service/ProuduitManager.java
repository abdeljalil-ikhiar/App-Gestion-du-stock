package com.example.gestion_stock.Service;

import com.example.gestion_stock.entities.Prouduit;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Service;


import java.util.List;
public interface ProuduitManager {
    public Prouduit addProuduit(Prouduit prouduit);
    public Prouduit updateProuduit(Prouduit prouduit);
    public boolean deleteProuduit(Integer id );

    public List<Prouduit> getAllProuduit();
    public Prouduit getProuduitById(Integer id);
    public List<Object[]> getStockFinal();

}
