package com.example.gestion_stock.repository;

import com.example.gestion_stock.entities.Sorties;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SortiesRepository extends JpaRepository<Sorties,Integer> {
}
