package com.example.gestion_stock.Web;
import com.example.gestion_stock.Service.ProuduitService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
@Controller
public class navbar {
    private ProuduitService prouduitService;
     @GetMapping("/")
      public String afficher(){
      return "layout";
  }
}