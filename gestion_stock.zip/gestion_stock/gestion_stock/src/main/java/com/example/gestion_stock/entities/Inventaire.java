package com.example.gestion_stock.entities;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
@Table(name = "Inventaire")
public class Inventaire {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer  InventaireID;
    @ManyToOne
    @JoinColumn(name = "Prouduit_id")
    private Prouduit prouduit;
    private double QuantiteInventaire;
    @DateTimeFormat(iso= DateTimeFormat.ISO.DATE)
    private Date DateInventaire;
    @Transient
    private Integer prouduitId;
}
