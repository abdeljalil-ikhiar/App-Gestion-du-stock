package com.example.gestion_stock.entities;
import jakarta.persistence.*;
import lombok.*;

import java.util.ArrayList;
import java.util.List;
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
@Table(name = "prouduit")
public class Prouduit {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer  id;
    private String Reference;
    private String Designation;
    @OneToMany(mappedBy = "prouduit", fetch = FetchType.LAZY)// Assuming 'entitierProuduit' is a property in the Entrer class
    private List<Entrer> entrers = new ArrayList<>();
    @OneToMany(mappedBy = "prouduit", fetch = FetchType.LAZY)
    private List<Sorties> sorties = new ArrayList<>();
    @OneToMany(mappedBy = "prouduit", fetch = FetchType.LAZY)
    private List<Inventaire> inventaires = new ArrayList<>();

    @Override
    public String toString() {
        return "Prouduit{}";
    }
}
